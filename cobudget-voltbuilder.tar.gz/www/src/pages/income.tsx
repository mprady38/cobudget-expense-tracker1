import { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation, useQuery } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";
import { isUnauthorizedError } from "@/lib/authUtils";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Card, CardContent } from "@/components/ui/card";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { insertIncomeSchema, type InsertIncomeData } from "@shared/schema";
import { z } from "zod";

const incomeFormSchema = insertIncomeSchema.extend({
  monthlySalary: z.string().transform(val => val.toString()),
  carryOver: z.string().transform(val => val.toString()),
});

type IncomeFormData = z.infer<typeof incomeFormSchema>;

export default function Income() {
  const { toast } = useToast();
  const { user, isAuthenticated, isLoading } = useAuth();
  const [totalMoney, setTotalMoney] = useState(0);

  const form = useForm<IncomeFormData>({
    resolver: zodResolver(incomeFormSchema),
    defaultValues: {
      user: "",
      monthYear: new Date().toISOString().slice(0, 7),
      monthlySalary: "",
      carryOver: "",
    },
  });

  // Redirect to login if not authenticated
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  // Set default user when auth data is available
  useEffect(() => {
    if (user?.label) {
      form.setValue("user", user.label);
    }
  }, [user, form]);

  // Watch form values to calculate total money
  const watchedValues = form.watch();
  useEffect(() => {
    const salary = parseFloat(watchedValues.monthlySalary) || 0;
    const carryOver = parseFloat(watchedValues.carryOver) || 0;
    setTotalMoney(salary + carryOver);
  }, [watchedValues.monthlySalary, watchedValues.carryOver]);

  const createIncomeMutation = useMutation({
    mutationFn: async (data: InsertIncomeData) => {
      const response = await apiRequest("POST", "/api/income", data);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Income recorded successfully!",
      });
      form.reset({
        user: user?.label || "",
        monthYear: new Date().toISOString().slice(0, 7),
        monthlySalary: "",
        carryOver: "",
      });
      // Invalidate dashboard cache
      queryClient.invalidateQueries({ queryKey: ["/api/analytics/dashboard"] });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      
      const errorMessage = error.message || "Failed to record income";
      toast({
        title: "Error",
        description: errorMessage,
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: IncomeFormData) => {
    createIncomeMutation.mutate({
      user: data.user,
      monthYear: data.monthYear,
      monthlySalary: data.monthlySalary,
      carryOver: data.carryOver,
    });
  };

  if (isLoading || !isAuthenticated) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto"></div>
          <p className="mt-2 text-sm text-gray-600">Loading...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="p-6">
      <div className="max-w-2xl mx-auto">
        <Card className="shadow-sm">
          <CardContent className="p-8">
            <div className="mb-6">
              <h2 className="text-2xl font-bold text-gray-900 mb-2">Add Monthly Income</h2>
              <p className="text-gray-600">Record your salary and carry-over amount for the month</p>
            </div>
            
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                <FormField
                  control={form.control}
                  name="user"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>User</FormLabel>
                      <Select onValueChange={field.onChange} value={field.value}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select user" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="Prady">Prady</SelectItem>
                          <SelectItem value="Rishita">Rishita</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="monthYear"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Month & Year</FormLabel>
                      <FormControl>
                        <Input type="month" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="monthlySalary"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Monthly Salary (₹)</FormLabel>
                      <FormControl>
                        <Input type="number" placeholder="Enter your monthly salary" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="carryOver"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Carry Over from Previous Month (₹)</FormLabel>
                      <FormControl>
                        <Input type="number" placeholder="Enter carry-over amount" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                {/* Total Money Display */}
                <div className="bg-blue-50 rounded-lg p-4 border border-blue-200">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium text-blue-900">Total Money in Account:</span>
                    <span className="text-xl font-bold text-blue-900">
                      ₹{totalMoney.toLocaleString()}
                    </span>
                  </div>
                  <p className="text-sm text-blue-600 mt-1">Monthly Salary + Carry Over</p>
                </div>
                
                <div className="flex gap-4">
                  <Button 
                    type="submit" 
                    className="flex-1"
                    disabled={createIncomeMutation.isPending}
                  >
                    {createIncomeMutation.isPending ? "Saving..." : "Save Income"}
                  </Button>
                  <Button 
                    type="button" 
                    variant="outline"
                    onClick={() => window.history.back()}
                  >
                    Cancel
                  </Button>
                </div>
              </form>
            </Form>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
