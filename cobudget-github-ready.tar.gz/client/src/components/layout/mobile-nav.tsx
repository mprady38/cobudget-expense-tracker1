import { Link, useLocation } from "wouter";
import { ChartLine, Coins, Receipt } from "lucide-react";
import { cn } from "@/lib/utils";

export function MobileNav() {
  const [location] = useLocation();

  const navigation = [
    { 
      name: "Dashboard", 
      href: "/", 
      icon: ChartLine,
      current: location === "/" 
    },
    { 
      name: "Income", 
      href: "/income", 
      icon: Coins,
      current: location === "/income" 
    },
    { 
      name: "Expenses", 
      href: "/expense", 
      icon: Receipt,
      current: location === "/expense" 
    },
  ];

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 lg:hidden z-40">
      <div className="flex justify-around py-2">
        {navigation.map((item) => {
          const Icon = item.icon;
          return (
            <Link key={item.name} href={item.href}>
              <div className={cn(
                "flex flex-col items-center py-2 px-4 cursor-pointer",
                item.current ? "text-primary" : "text-gray-500"
              )}>
                <Icon size={20} />
                <span className="text-xs mt-1">{item.name}</span>
              </div>
            </Link>
          );
        })}
      </div>
    </div>
  );
}
