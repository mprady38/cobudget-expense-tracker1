import {
  users,
  income,
  expenses,
  type User,
  type UpsertUser,
  type Income,
  type InsertIncome,
  type Expense,
  type InsertExpense,
} from "@shared/schema";
import { db } from "./db";
import { eq, and, sql, desc } from "drizzle-orm";

export interface IStorage {
  // User operations (mandatory for Replit Auth)
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  
  // Income operations
  createIncome(incomeData: InsertIncome): Promise<Income>;
  getIncomeByUserAndMonth(user: string, monthYear: string): Promise<Income | undefined>;
  getIncomeByUser(user: string): Promise<Income[]>;
  
  // Expense operations
  createExpense(expenseData: InsertExpense): Promise<Expense>;
  getExpensesByMonth(monthYear: string): Promise<Expense[]>;
  getExpensesByUser(user: string): Promise<Expense[]>;
  getExpensesByUserAndMonth(user: string, monthYear: string): Promise<Expense[]>;
  getExpensesByCategory(): Promise<{ category: string; total: string }[]>;
  getMonthlyExpenseTrends(monthsBack: number): Promise<{ month: string; total: string }[]>;
  getExpensesBySpender(): Promise<{ spender: string; total: string }[]>;
}

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  // Income operations
  async createIncome(incomeData: InsertIncome): Promise<Income> {
    const [newIncome] = await db.insert(income).values(incomeData).returning();
    return newIncome;
  }

  async getIncomeByUserAndMonth(user: string, monthYear: string): Promise<Income | undefined> {
    const [incomeRecord] = await db
      .select()
      .from(income)
      .where(and(eq(income.user, user), eq(income.monthYear, monthYear)));
    return incomeRecord;
  }

  async getIncomeByUser(user: string): Promise<Income[]> {
    return await db.select().from(income).where(eq(income.user, user)).orderBy(desc(income.monthYear));
  }

  // Expense operations
  async createExpense(expenseData: InsertExpense): Promise<Expense> {
    const [newExpense] = await db.insert(expenses).values(expenseData).returning();
    return newExpense;
  }

  async getExpensesByMonth(monthYear: string): Promise<Expense[]> {
    const year = monthYear.split('-')[0];
    const month = monthYear.split('-')[1];
    
    return await db
      .select()
      .from(expenses)
      .where(
        and(
          sql`EXTRACT(YEAR FROM ${expenses.expenseDate}) = ${year}`,
          sql`EXTRACT(MONTH FROM ${expenses.expenseDate}) = ${month}`
        )
      )
      .orderBy(desc(expenses.expenseDate));
  }

  async getExpensesByUser(user: string): Promise<Expense[]> {
    return await db
      .select()
      .from(expenses)
      .where(eq(expenses.spender, user))
      .orderBy(desc(expenses.expenseDate));
  }

  async getExpensesByUserAndMonth(user: string, monthYear: string): Promise<Expense[]> {
    const year = monthYear.split('-')[0];
    const month = monthYear.split('-')[1];
    
    return await db
      .select()
      .from(expenses)
      .where(
        and(
          eq(expenses.spender, user),
          sql`EXTRACT(YEAR FROM ${expenses.expenseDate}) = ${year}`,
          sql`EXTRACT(MONTH FROM ${expenses.expenseDate}) = ${month}`
        )
      )
      .orderBy(desc(expenses.expenseDate));
  }

  async getExpensesByCategory(): Promise<{ category: string; total: string }[]> {
    return await db
      .select({
        category: expenses.category,
        total: sql<string>`SUM(${expenses.amount})::text`,
      })
      .from(expenses)
      .groupBy(expenses.category)
      .orderBy(sql`SUM(${expenses.amount}) DESC`);
  }

  async getMonthlyExpenseTrends(monthsBack: number = 6): Promise<{ month: string; total: string }[]> {
    return await db
      .select({
        month: sql<string>`TO_CHAR(${expenses.expenseDate}, 'YYYY-MM')`,
        total: sql<string>`SUM(${expenses.amount})::text`,
      })
      .from(expenses)
      .where(sql`${expenses.expenseDate} >= CURRENT_DATE - INTERVAL '${sql.raw(monthsBack.toString())} months'`)
      .groupBy(sql`TO_CHAR(${expenses.expenseDate}, 'YYYY-MM')`)
      .orderBy(sql`TO_CHAR(${expenses.expenseDate}, 'YYYY-MM')`);
  }

  async getExpensesBySpender(): Promise<{ spender: string; total: string }[]> {
    return await db
      .select({
        spender: expenses.spender,
        total: sql<string>`SUM(${expenses.amount})::text`,
      })
      .from(expenses)
      .groupBy(expenses.spender)
      .orderBy(sql`SUM(${expenses.amount}) DESC`);
  }
}

export const storage = new DatabaseStorage();
