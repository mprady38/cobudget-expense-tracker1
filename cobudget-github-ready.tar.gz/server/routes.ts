import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth, isAuthenticated } from "./replitAuth";
import { insertIncomeSchema, insertExpenseSchema } from "@shared/schema";
import { z } from "zod";

// Helper function to get user label from email
function getUserLabelFromEmail(email: string): string | null {
  if (email === "mpradyumna38@gmail.com") return "Prady";
  if (email === "allikarishita.44@gmail.com") return "Rishita";
  return null;
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth middleware
  await setupAuth(app);

  // Auth routes
  app.get('/api/auth/user', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      // Add user label based on email
      const userLabel = getUserLabelFromEmail(user.email || "");
      
      res.json({
        ...user,
        label: userLabel,
      });
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // Income routes
  app.post('/api/income', isAuthenticated, async (req: any, res) => {
    try {
      const user = await storage.getUser(req.user.claims.sub);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      const userLabel = getUserLabelFromEmail(user.email || "");
      if (!userLabel) {
        return res.status(403).json({ message: "Unauthorized user" });
      }

      const validatedData = insertIncomeSchema.parse({
        ...req.body,
        user: userLabel,
      });

      // Check if income already exists for this month
      const existingIncome = await storage.getIncomeByUserAndMonth(
        validatedData.user,
        validatedData.monthYear
      );

      if (existingIncome) {
        return res.status(409).json({ message: "Income already recorded for this month" });
      }

      const newIncome = await storage.createIncome(validatedData);
      res.status(201).json(newIncome);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Validation error", errors: error.errors });
      }
      console.error("Error creating income:", error);
      res.status(500).json({ message: "Failed to create income" });
    }
  });

  app.get('/api/income/:monthYear', isAuthenticated, async (req: any, res) => {
    try {
      const user = await storage.getUser(req.user.claims.sub);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      const userLabel = getUserLabelFromEmail(user.email || "");
      if (!userLabel) {
        return res.status(403).json({ message: "Unauthorized user" });
      }

      const income = await storage.getIncomeByUserAndMonth(userLabel, req.params.monthYear);
      res.json(income || null);
    } catch (error) {
      console.error("Error fetching income:", error);
      res.status(500).json({ message: "Failed to fetch income" });
    }
  });

  // Expense routes
  app.post('/api/expenses', isAuthenticated, async (req: any, res) => {
    try {
      const user = await storage.getUser(req.user.claims.sub);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      const userLabel = getUserLabelFromEmail(user.email || "");
      if (!userLabel) {
        return res.status(403).json({ message: "Unauthorized user" });
      }

      const validatedData = insertExpenseSchema.parse(req.body);
      const newExpense = await storage.createExpense(validatedData);
      res.status(201).json(newExpense);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Validation error", errors: error.errors });
      }
      console.error("Error creating expense:", error);
      res.status(500).json({ message: "Failed to create expense" });
    }
  });

  app.get('/api/expenses/:monthYear', isAuthenticated, async (req: any, res) => {
    try {
      const expenses = await storage.getExpensesByMonth(req.params.monthYear);
      res.json(expenses);
    } catch (error) {
      console.error("Error fetching expenses:", error);
      res.status(500).json({ message: "Failed to fetch expenses" });
    }
  });

  // Dashboard analytics routes
  app.get('/api/analytics/dashboard/:monthYear', isAuthenticated, async (req: any, res) => {
    try {
      const { monthYear } = req.params;
      
      // Get expenses for the month
      const monthlyExpenses = await storage.getExpensesByMonth(monthYear);
      
      // Get income for both users for the month
      const pradyIncome = await storage.getIncomeByUserAndMonth("Prady", monthYear);
      const rishitaIncome = await storage.getIncomeByUserAndMonth("Rishita", monthYear);
      
      // Calculate totals
      const totalIncome = Number(pradyIncome?.monthlySalary || 0) + Number(pradyIncome?.carryOver || 0) +
                         Number(rishitaIncome?.monthlySalary || 0) + Number(rishitaIncome?.carryOver || 0);
      
      const totalExpenses = monthlyExpenses.reduce((sum, expense) => sum + Number(expense.amount), 0);
      
      const savingsExpenses = monthlyExpenses
        .filter(expense => expense.category === "Saving & Investment")
        .reduce((sum, expense) => sum + Number(expense.amount), 0);
      
      const loanExpenses = monthlyExpenses
        .filter(expense => expense.category === "Loan")
        .reduce((sum, expense) => sum + Number(expense.amount), 0);
      
      const moneyLeft = totalIncome - totalExpenses;
      const savingsPercent = totalIncome > 0 ? (savingsExpenses / totalIncome) * 100 : 0;
      const loanPercent = totalIncome > 0 ? (loanExpenses / totalIncome) * 100 : 0;

      // Person-wise spending
      const pradySpending = monthlyExpenses
        .filter(expense => expense.spender === "Prady")
        .reduce((sum, expense) => sum + Number(expense.amount), 0);
      
      const rishitaSpending = monthlyExpenses
        .filter(expense => expense.spender === "Rishita")
        .reduce((sum, expense) => sum + Number(expense.amount), 0);

      res.json({
        totalIncome,
        totalExpenses,
        totalSavings: savingsExpenses,
        loanPayments: loanExpenses,
        moneyLeft,
        savingsPercent: Math.round(savingsPercent * 10) / 10,
        loanPercent: Math.round(loanPercent * 10) / 10,
        pradySpending,
        rishitaSpending,
      });
    } catch (error) {
      console.error("Error fetching dashboard analytics:", error);
      res.status(500).json({ message: "Failed to fetch dashboard analytics" });
    }
  });

  app.get('/api/analytics/category-spending', isAuthenticated, async (req: any, res) => {
    try {
      const categoryData = await storage.getExpensesByCategory();
      res.json(categoryData);
    } catch (error) {
      console.error("Error fetching category spending:", error);
      res.status(500).json({ message: "Failed to fetch category spending" });
    }
  });

  app.get('/api/analytics/monthly-trends', isAuthenticated, async (req: any, res) => {
    try {
      const trends = await storage.getMonthlyExpenseTrends(6);
      res.json(trends);
    } catch (error) {
      console.error("Error fetching monthly trends:", error);
      res.status(500).json({ message: "Failed to fetch monthly trends" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
