import { Link, useLocation } from "wouter";
import { Wallet, ChartLine, Coins, Receipt } from "lucide-react";
import { cn } from "@/lib/utils";
import { useAuth } from "@/hooks/useAuth";

interface SidebarProps {
  isOpen: boolean;
  onClose: () => void;
}

export function Sidebar({ isOpen, onClose }: SidebarProps) {
  const [location] = useLocation();
  const { user } = useAuth();

  const navigation = [
    { 
      name: "Dashboard", 
      href: "/", 
      icon: ChartLine,
      current: location === "/" 
    },
    { 
      name: "Income", 
      href: "/income", 
      icon: Coins,
      current: location === "/income" 
    },
    { 
      name: "Expenses", 
      href: "/expense", 
      icon: Receipt,
      current: location === "/expense" 
    },
  ];

  return (
    <>
      {/* Overlay for mobile */}
      {isOpen && (
        <div 
          className="fixed inset-0 bg-black bg-opacity-50 z-40 lg:hidden" 
          onClick={onClose}
        />
      )}
      
      {/* Sidebar */}
      <div className={cn(
        "fixed inset-y-0 left-0 z-50 w-64 bg-white shadow-lg transform transition-transform duration-300 lg:translate-x-0",
        isOpen ? "translate-x-0" : "-translate-x-full"
      )}>
        <div className="flex items-center gap-3 p-6 border-b">
          <div className="w-10 h-10 bg-primary rounded-full flex items-center justify-center">
            <Wallet className="text-white" size={20} />
          </div>
          <div>
            <h2 className="text-xl font-bold text-gray-900">CoBudget</h2>
            <p className="text-sm text-gray-500">{user?.label || "User"}</p>
          </div>
        </div>
        
        <nav className="p-4 space-y-2">
          {navigation.map((item) => {
            const Icon = item.icon;
            return (
              <Link key={item.name} href={item.href}>
                <div
                  className={cn(
                    "flex items-center gap-3 px-4 py-3 rounded-lg transition-colors cursor-pointer",
                    item.current
                      ? "bg-primary text-white"
                      : "text-gray-700 hover:bg-gray-100"
                  )}
                  onClick={onClose}
                >
                  <Icon size={20} />
                  <span>{item.name}</span>
                </div>
              </Link>
            );
          })}
        </nav>
      </div>
    </>
  );
}
