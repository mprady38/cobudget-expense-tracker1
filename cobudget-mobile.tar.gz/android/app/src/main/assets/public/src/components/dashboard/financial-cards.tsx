import { Card, CardContent } from "@/components/ui/card";
import { ArrowUp, ArrowDown, Wallet, PiggyBank, TrendingUp, DollarSign } from "lucide-react";

interface FinancialCardsProps {
  data?: {
    totalIncome: number;
    totalExpenses: number;
    moneyLeft: number;
    savingsPercent: number;
    totalSavings: number;
    loanPayments: number;
    loanPercent: number;
    pradySpending: number;
    rishitaSpending: number;
  };
  isLoading: boolean;
}

export function FinancialCards({ data, isLoading }: FinancialCardsProps) {
  if (isLoading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {[...Array(4)].map((_, i) => (
          <Card key={i}>
            <CardContent className="p-6">
              <div className="animate-pulse">
                <div className="h-4 bg-gray-200 rounded w-3/4 mb-2"></div>
                <div className="h-8 bg-gray-200 rounded w-1/2"></div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  const cards = [
    {
      title: "Total Income",
      value: data?.totalIncome || 0,
      icon: ArrowUp,
      iconBg: "bg-green-100",
      iconColor: "text-green-600",
    },
    {
      title: "Total Expenses", 
      value: data?.totalExpenses || 0,
      icon: ArrowDown,
      iconBg: "bg-red-100",
      iconColor: "text-red-600",
    },
    {
      title: "Money Left",
      value: data?.moneyLeft || 0,
      icon: Wallet,
      iconBg: "bg-blue-100", 
      iconColor: "text-blue-600",
    },
    {
      title: "Savings %",
      value: `${data?.savingsPercent || 0}%`,
      icon: PiggyBank,
      iconBg: "bg-purple-100",
      iconColor: "text-purple-600",
      isPercentage: true,
    },
  ];

  return (
    <>
      {/* Main Financial Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {cards.map((card) => {
          const Icon = card.icon;
          return (
            <Card key={card.title}>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">{card.title}</p>
                    <p className="text-2xl font-bold text-gray-900">
                      {card.isPercentage ? card.value : `₹${Number(card.value).toLocaleString()}`}
                    </p>
                  </div>
                  <div className={`w-12 h-12 ${card.iconBg} rounded-full flex items-center justify-center`}>
                    <Icon className={card.iconColor} size={20} />
                  </div>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Additional Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <div>
                <p className="text-sm font-medium text-gray-600">Total Savings</p>
                <p className="text-xl font-bold text-green-600">
                  ₹{Number(data?.totalSavings || 0).toLocaleString()}
                </p>
              </div>
              <div className="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center">
                <TrendingUp className="text-green-600" size={20} />
              </div>
            </div>
            <p className="text-sm text-gray-500">Investment & Savings category</p>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <div>
                <p className="text-sm font-medium text-gray-600">Loan Payments</p>
                <p className="text-xl font-bold text-orange-600">
                  ₹{Number(data?.loanPayments || 0).toLocaleString()}
                </p>
              </div>
              <div className="w-10 h-10 bg-orange-100 rounded-full flex items-center justify-center">
                <DollarSign className="text-orange-600" size={20} />
              </div>
            </div>
            <p className="text-sm text-gray-500">{data?.loanPercent || 0}% of total income</p>
          </CardContent>
        </Card>
      </div>

      {/* Person-wise Spending */}
      <Card>
        <CardContent className="p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Person-wise Spending</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="flex items-center justify-between p-4 bg-blue-50 rounded-lg">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-primary rounded-full flex items-center justify-center">
                  <span className="text-white font-semibold">P</span>
                </div>
                <div>
                  <p className="font-semibold text-gray-900">Prady</p>
                  <p className="text-2xl font-bold text-primary">
                    ₹{Number(data?.pradySpending || 0).toLocaleString()}
                  </p>
                </div>
              </div>
              <div className="text-right">
                <p className="text-sm text-gray-600">
                  {data?.totalExpenses && data.totalExpenses > 0
                    ? Math.round((Number(data.pradySpending || 0) / data.totalExpenses) * 100 * 10) / 10
                    : 0}%
                </p>
              </div>
            </div>
            
            <div className="flex items-center justify-between p-4 bg-pink-50 rounded-lg">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-pink-500 rounded-full flex items-center justify-center">
                  <span className="text-white font-semibold">R</span>
                </div>
                <div>
                  <p className="font-semibold text-gray-900">Rishita</p>
                  <p className="text-2xl font-bold text-pink-500">
                    ₹{Number(data?.rishitaSpending || 0).toLocaleString()}
                  </p>
                </div>
              </div>
              <div className="text-right">
                <p className="text-sm text-gray-600">
                  {data?.totalExpenses && data.totalExpenses > 0
                    ? Math.round((Number(data.rishitaSpending || 0) / data.totalExpenses) * 100 * 10) / 10
                    : 0}%
                </p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </>
  );
}
